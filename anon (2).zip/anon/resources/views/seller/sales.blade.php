@extends('master.main')

@section('title', 'Sales')

@section('content')

<section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;">
                <h6 class="text-dark" style="padding-top: 11px;padding-left: 15px;padding-right: 15px;margin-bottom: -6px;font-size: 19px;">Sales</h6>
                <hr style="margin-bottom: 15px;">
                <div class="row" style="padding-right: 66px;padding-left: 66px;">
                    <div class="col"><a  href="{{ route('sales', ['status' => 'all']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">All {{ $user->sales()->count() }}</a></div>
                    <div class="col"><a href="{{ route('sales', ['status' => 'waiting']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Waiting {{ $user->totalSales('waiting') }}</a></div>
                    <div class="col"><a  href="{{ route('sales', ['status' => 'accepted']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Accepted  {{ $user->totalSales('accepted') }}</a></div>
                    <div class="col"><a href="{{ route('sales', ['status' => 'shipped']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Shipped {{ $user->totalSales('shipped') }}</a></div>
                    <div class="col"><a href="{{ route('sales', ['status' => 'delivered']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Delivered  {{ $user->totalSales('delivered') }}</a></div>
                    <div class="col"><a href="{{ route('sales', ['status' => 'canceled']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Canceled  {{ $user->totalSales('canceled') }}</a></div>
                    <div class="col"><a href="{{ route('sales', ['status' => 'disputed']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Disputed  {{ $user->totalSales('disputed') }}</a></div>
                   
                </div>
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;"><br></p>
            </div>
        </div>
    </section>
  <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
            
                <div class="row">
                    <div class="col">
                        <div class="card shadow" style="background: rgba(87,101,242,0.09);border-color: rgba(33,37,41,0);padding-bottom: 5px;">
                            <div class="card-body">
                                <div class="table-responsive table mb-0 pt-3 pe-2">
                                    <table class="table table-striped table-sm my-0 mydatatable">
                                    
		<thead>
			<tr>
				<th>Product</th>
				<th>Buyer</th>
				<th>Total</th>
				<th>Status</th>
				<th>UUID</th>
			</tr>
		</thead>
		<tbody>
			@forelse($sales as $sale)
				<tr>
					<td><a href="{{ route('product', ['product' => $sale->product->id ]) }}">{{ $sale->product->name }}</a></td>
					<td>{{ $sale->buyer->username }}</td>
					<td>@include('includes.components.displayprice', ['price' => $sale->total])</td>
					<td><strong>{{ $sale->status }}</strong></td>
					<td><a href="{{ route('order', ['order' => $sale->id]) }}">{{ $sale->id }}</a></td>
				</tr>
			@empty
				<tr>
					<td colspan="6">Hmm... Looks like you don't have any sales yet.</td>
				</tr>
			@endforelse
			<tr>
				<td colspan="6">{{ $sales->links('includes.components.pagination') }}</td>
			</tr>
		</tbody>
	</table>
   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>



@stop