@extends('master.main')

@section('title',  'Wiki')

@section('content')

<div class="content-browsing">
   <div class="container about">
      <p class="h3">How to purchase with other crypto coins</p>

      <p>If you wish to purchase using any other coin other than Monero please message <strong>BlackBlade</strong>. A wallet will be provided immediately for your purchase and vendor notified.</p>
   </div>
</div>

@stop