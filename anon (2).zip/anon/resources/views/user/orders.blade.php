@extends('master.main')

@section('title', 'Orders')

@section('content')

 <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 25px;">
                <h5 class="text-dark" style="padding-top: 20px;padding-left: 15px;padding-right: 15px;">Orders</h5>
                <hr style="margin-bottom: 15px;">
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 25px;">Please click on your order UUID link and proceed with payment. Notify BlackBlade immediately after payment.&nbsp;<br><br></p>
            </div>
        </div>
    </section>
<section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;">
                <h6 class="text-dark" style="padding-top: 11px;padding-left: 15px;padding-right: 15px;margin-bottom: -6px;font-size: 19px;"></h6>
                <hr style="margin-bottom: 15px;">
                <div class="row" style="padding-right: 66px;padding-left: 66px;">
                    <div class="col"><a  href="{{ route('orders', ['status' => 'all']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">All {{ $user->orders->count() }}</a></div>
                    <div class="col"><a href="{{ route('orders', ['status' => 'waiting']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Waiting {{ $user->totalOrders('waiting') }}</a></div>
                    <div class="col"><a  href="{{ route('orders', ['status' => 'accepted']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Accepted  {{ $user->totalOrders('accepted') }}</a></div>
                    <div class="col"><a href="{{ route('orders', ['status' => 'shipped']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Shipped {{ $user->totalOrders('shipped') }}</a></div>
                    <div class="col"><a href="{{ route('orders', ['status' => 'delivered']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Delivered  {{ $user->totalOrders('delivered') }}</a></div>
                    <div class="col"><a href="{{ route('orders', ['status' => 'canceled']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Canceled  {{ $user->totalOrders('canceled') }}</a></div>
                    <div class="col"><a href="{{ route('orders', ['status' => 'disputed']) }}" style="font-size: 16px;color: var(--bs-blue);padding-right: 0px;">Disputed  {{ $user->totalOrders('disputed') }}</a></div>
                   
                </div>
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;"><br></p>
            </div>
        </div>
    </section>

    <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
            
                <div class="row">
                    <div class="col">
                        <div class="card shadow" style="background: rgba(87,101,242,0.09);border-color: rgba(33,37,41,0);padding-bottom: 5px;">
                            <div class="card-body">
                                <div class="table-responsive table mb-0 pt-3 pe-2">
                                    <table class="table table-striped table-sm my-0 mydatatable">
                                      <thead>
			<tr>
				<th>Product</th>
				<th>Vendor</th>
				<th>Finalize early</th>
				<th>Total</th>
				<th>Status</th>
				<th>UUID</th>
			</tr>
		</thead>
		<tbody>
			@forelse($orders as $order)
				<tr>
					<td><a href="{{ route('product', ['product' => $order->product->id ]) }}">{{ $order->product->name }}</a></td>
					<td><a href="{{ route('seller', ['seller' => $order->seller->username]) }}">{{ $order->seller->username }}</a></td>
					<td>{{ $order->seller->fe == true ? 'Yes' : 'No' }}</td>
					<td>@include('includes.components.displayprice', ['price' => $order->total])</td>
					<td><strong>{{ $order->status }}</strong></td>
					<td><a href="{{ route('order', ['order' => $order->id]) }}">{{ $order->id }}</a></td>
				</tr>
			@empty
				<tr>
					<td colspan="7">Hmm... Looks like you don't have any orders yet.</td>
				</tr>
			@endforelse
				<tr>
					<td colspan="7">{{ $orders->links('includes.components.pagination') }}</td>
				</tr>
		</tbody>
	</table>
   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>


@stop