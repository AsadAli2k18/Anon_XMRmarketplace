@extends('master.main')

@section('title', 'Account index')

@section('content')

@include('includes.components.menuaccount')
<div class="content-profile">
    @include('includes.flash.validation')
    @include('includes.flash.success')
    @include('includes.flash.error')
   
</div>


 <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 25px;">
                <h5 class="text-dark" style="padding-top: 20px;padding-left: 15px;padding-right: 15px;">Useful Information</h5>
                <hr style="margin-bottom: 15px;">
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 35px;">These are some information you need to know about the market. Always refer to these notes before opening a help request.If you place an order and do not pay within 2 days, the order is automatically canceled and any money placed in the custody wallet is refunded.Orders marked as canceled or delivered will be deleted within 7 days.All your conversations and messages are automatically deleted after 30 days.Orders with shipped status are finalized after 30 days.Help requests marked as closed are deleted after 30 days.If you want to get more information about how the market works and how to use it, see the&nbsp;<a href="http://localhost/wiki" target="_blank"><strong>wiki</strong></a>.<br><br></p>
            </div>
        </div>
    </section>

@stop
