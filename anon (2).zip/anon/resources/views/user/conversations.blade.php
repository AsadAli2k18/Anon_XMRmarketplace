@extends('master.main')

@section('title', 'Conversations')

@section('content')

 <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
                <h6 class="text-dark" style="padding-top: 11px;padding-left: 15px;padding-right: 10px;margin-bottom: -6px;font-size: 19px;"><br>All conversations (active or not) older than 30 days will be deleted!<br><br></h6>
             
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>

 <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
            
                <div class="row">
                    <div class="col">
                        <div class="card shadow" style="background: rgba(87,101,242,0.09);border-color: rgba(33,37,41,0);padding-bottom: 5px;">
                            <div class="card-body">
                                <div class="table-responsive table mb-0 pt-3 pe-2">
                                    <table class="table table-striped table-sm my-0 mydatatable">
                                        <thead>
                                            <tr>
                                                <th>User<br></th>
                                                <th>Unread<br></th>
                                                <th>TotalMessages</th>
                                                <th>#</th>
                                            </tr>
                                        </thead>
                                    @foreach($conversations as $conversation)
            <tr>
                <td style="white-space: nowrap">{{ $conversation->otherUser() }}</td>
                <td>{{ $conversation->unreadMessages() }}</td>
                <td>{{ $conversation->totalMessages() }}</td>
                <td><a href="{{ route('conversationmessages', ['conversation' => $conversation->id]) }}">view</a></td>
            </tr>
            @endforeach
        </tbody>
    </table>
    {{ $conversations->links('includes.components.pagination') }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>







    <section class="contact-clean" style="margin-bottom: 23px;background: rgb(250,250,250);">
             @include('includes.flash.error')
       <form action="{{ route('post.conversations') }}" method="post">
        @csrf
            <h2 class="text-center">Create a new conversation<br></h2>

            <div class="mb-3"><input class="form-control" id="username" name="username" value="{{ $user }}" placeholder="Receivers username"></div>

            @error('username')
            <div class="error">
                <small class="text-danger">{{ $errors->first('username') }}</small>
            </div> 
            @enderror



            <div class="mb-3"></div>

            <div class="mb-3"><textarea class="form-control" id="message" name="message" placeholder="Message" rows="14"></textarea></div>

            @error('message')
            <div class="error">
                <small class="text-danger">{{ $errors->first('message') }}</small>
            </div> 
            @enderror
            <div class="form-check"><input class="form-check-input" type="checkbox" id="encrypted" name="encrypted" value="1"><label class="form-check-label" for="encrypted">Auto encrypt<br></label></div><small class="form-text text-danger"><br>The message will automatically be encrypted with the PGP key of the receiving user.<br><br></small>

           <div class="form-group">
 <div class="mb-3"> <div class="captcha" style=margin-bottom:5px;>
    {!! Captcha::img() !!} 
    </div> </div>
    
       <div class="mb-3"><p></p><input class="form-control" style="width: 200px;" type="text" id="captcha" name="captcha" placeholder="Enter Captcha"></div>
               
<!--    <button type="submit" style=background-color:#5865F2;border:none;>Go</button> -->
        <div class="mb-3"><p></p><button class="btn btn-dark" style="width: 200px;background: rgb(13,110,253);border-style: none;border-radius: 119px;padding-top: 20px" type="Submit">Send</button></div>
    @error('captcha')
    <div class="error">
        <small class="text-danger">{{ $errors->first('captcha') }}</small>
    </div>
    @enderror
</div>




          
        </form>
    </section>

@stop