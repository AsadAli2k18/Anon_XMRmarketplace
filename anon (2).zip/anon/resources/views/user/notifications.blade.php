@extends('master.main')

@section('title', 'Notifications')

@section('content')

<section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
                <h6 class="text-dark" style="padding-top: 11px;padding-left: 15px;padding-right: 10px;margin-bottom: -6px;font-size: 19px;"><br>Notifications ({{ auth()->user()->totalUnreadNotifications() }})<br><br></h6><form action="{{ route('delete.notifications') }}" method="post" class="mb-10">
		@csrf
		@method('delete')
		<button class="btn btn-primary" type="submit">Clear</button>
	</form>
             
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>








 <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
            
                <div class="row">
                    <div class="col">
                        <div class="card shadow" style="background: rgba(87,101,242,0.09);border-color: rgba(33,37,41,0);padding-bottom: 5px;">
                            <div class="card-body">
                                <div class="table-responsive table mb-0 pt-3 pe-2">
                                    <table class="table table-striped table-sm my-0 mydatatable">
                                      	<thead>
		
		</thead>
		<tbody>
			@forelse($notifications as $notification)
			<tr>
				<td style="text-align: left;">{!! $notification->label !!}</td>
			</tr>
			@empty
			<tr>
				<td colspan="2">Hmm... Looks like you don't have any notifications!</td>
			</tr>
			@endforelse
			<tr>
				<td colspan="2">{{ $notifications->links('includes.components.pagination') }}</td>
			</tr>
		</tbody>
	</table>
  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>


    @stop