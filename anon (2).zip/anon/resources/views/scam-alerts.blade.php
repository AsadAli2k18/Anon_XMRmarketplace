@extends('master.main')

@section('title',  'Wiki')

@section('content')

<div class="content-browsing">
   <div class="container about">
      <p class="h3">Scam Alerts</p>

      <p><i>No alerts yet!!! Notify us immediately if you encounter any scam attempt.</i></p>
   </div>
</div>

@stop