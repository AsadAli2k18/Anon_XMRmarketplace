<script type="text/javascript">
    document.write("Javascript is enabled. You are putting yourself at risk!")
 </script>