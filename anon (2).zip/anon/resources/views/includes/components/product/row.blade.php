
 <div class="col-lg-4"><a href="{{ route('product', ['product' => $product->id]) }}">
                        <div class="card mb-4 box-shadow rounded-0"><img class="card-img-top w-100 d-block rounded-0" src="{{ $product->featuredImage() }}" width="130px" height="420px" alt="No image">
                            <div class="card-body">
                                <h4 class="card-title" style="margin-bottom: 11px;">{{ $product->name }}</h4>
                                <h6 class="text-muted card-subtitle mb-2"><strong>Seller&nbsp; &nbsp;&nbsp;</strong><a href="{{ route('seller', ['seller' => $product->seller->username]) }}">{{ $product->seller->username }}({{ $product->seller->totalFeedbacks() }})</a><br></h6>
                                <p class="card-text" style="margin-bottom: 5px;"><strong>Ships to</strong>: {{ $product->shipsTo() }}<br></p>
                                <p class="card-text"><strong>Ships from</strong>: {{ $product->shipsFrom() }}<br></p>
                                <div class="row">
                                    <div class="col">
                                        <p style="font-size: 18px;"><strong>from&nbsp; @include('includes.components.displayprice', ['price' => $product->from()])</strong><br></p>
                                    </div>
                                    <div class="col text-end">
                                    	<form action="{{ route('post.favorites', ['product' => $product->id]) }}" method="post">
			@csrf
			<button style="background-color:white;font-size: 19px;color: var(--bs-blue);">{{ auth()->user()->isFavorite($product) ? 'remove' : 'add' }} to favorites</button>
		</form>


                                    	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a></div>