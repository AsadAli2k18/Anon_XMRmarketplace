<div class="form-group">
 <div class="form-group d-flex justify-content-center">	<div class="captcha" style=margin-bottom:5px;>
	{!! Captcha::img() !!} 
	</div> </div>
	
	   <div class="form-group d-flex justify-content-center"><input class="form-control" style="width: 200px;" type="text" id="captcha" name="captcha" placeholder="Enter Captcha"></div>
               
<!--	<button type="submit" style=background-color:#5865F2;border:none;>Go</button> -->
	   <div class="form-group d-flex justify-content-center"><button class="btn btn-dark" style="width: 200px;background: rgb(13,110,253);border-style: none;border-radius: 119px;" type="Submit">Go</button></div>
	@error('captcha')
	<div class="error">
		<small class="text-danger">{{ $errors->first('captcha') }}</small>
	</div>
	@enderror
</div>