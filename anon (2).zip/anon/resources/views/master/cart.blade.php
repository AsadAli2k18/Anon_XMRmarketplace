@extends('master.main')

@section('title', "Shopping cart ($totalProducts)")

@section('content')

<section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
                <h6 class="text-dark" style="padding-top: 11px;padding-left: 15px;padding-right: 10px;margin-bottom: -6px;font-size: 19px;"><br>Shopping cart ({{ $totalProducts }})<br><br>@include('includes.flash.success')
	@include('includes.flash.error')</h6>

	<form action="{{ route('post.clearcart') }}" method="post">
			@csrf
			<button class="btn btn-primary">Clear cart</button>
		</form>
             
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>

  <section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;margin: 60px;border-radius: 26px;margin-top: 25px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;">
            
                <div class="row">
                    <div class="col">
                        <div class="card shadow" style="background: rgba(87,101,242,0.09);border-color: rgba(33,37,41,0);padding-bottom: 5px;">
                            <div class="card-body">
                                <div class="table-responsive table mb-0 pt-3 pe-2">
                                    <table class="table table-striped table-sm my-0 mydatatable">
                                    	<thead>
			<tr>
				<th>Product</th>
				<th>Seller</th>
				<th>Quantity</th>
				<th>Price</th>
				<th>Delivery</th>
				<th>Sub-total</th>
				<th>#</th>
			</tr>
		</thead>
		<tbody>
			@forelse($products as $product)
				<tr>
					<td><a href="{{ route('product', ['product' => $product['product_id'] ]) }}">{{ $product['product_name'] }}</a></td>
					<td><a href="{{ route('seller', ['seller' => $product['seller'] ]) }}">{{ $product['seller'] }}</a></td>
					<td>{{ $product['quantity'] }}</td>
					<td>@include('includes.components.displayprice', ['price' => $product['price']])</td>
					<td>{{ $product['delivery_method'] }} - @include('includes.components.displayprice', ['price' => $product['delivery_price']])</td>
					<td>@include('includes.components.displayprice', ['price' => $product['total']])</td>
					<td>
						<form action="{{ route('post.removetocart', ['product' => $product['product_id'] ]) }}" method="post">
							@csrf
							<button type="submit" class="btn-link">Remove</button>
						</form>
					</td>
				</tr>
			@empty
				<tr>
					<td colspan="7">Your shopping cart is empty!</td>
				</tr>
			@endforelse
		</tbody>
	</table>
   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>

<section class="bg-white" style="background: rgba(255,255,255,0);">
        <div class="container-fluid" style="padding-right: 0px;padding-left: 0px;background: var(--bs-light);">
            <div style="text-align: center;background: rgba(87,101,242,0.09);margin: 60px;border-radius: 26px;margin-top: 30px;margin-right: 60px;margin-left: 60px;margin-bottom: 44px;"><br>
               	<div style="font-weight: bold; font-size: 25px">Total: @include('includes.components.displayprice', ['price' => $totalPrice])</div>
               	<hr style="margin-bottom: 15px;">
		<div class="footnote mb-15">Approximately {{ \App\Tools\Converter::moneroConverter($totalPrice) }} XMR</div>


                <p class="text-black-50" style="padding-left: 34px;padding-right: 34px;padding-bottom: 0px;margin-bottom: -29px;"><br></p>
            </div>
        </div>
    </section>


    <section class="contact-clean" style="margin-bottom: 23px;background: rgb(250,250,250);">
           
       <form action="{{ route('post.checkout') }}" method="post">
        @csrf
            <h2 class="text-center">Checkout<br></h2>



   <small class="form-text text-danger"><br>Your address will be encrypted with the sellers' PGP key, ensuring that only they will have access to your information! See how we protect your identity in the <a href="{{ config('general.wiki_link') }}" target="_blank"><strong>buyer's guide</strong></a>.</small>
            <div class="mb-3"></div>

            <div class="mb-3"><textarea class="form-control" id="address" name="address" placeholder="Your name and address" rows="14"></textarea></div>

           	@error('address')
			<div class="error">
				<small class="text-danger">{{ $errors->first('address') }}</small>
			</div>
			@enderror
 

    	<div class="mt-10">
				<label for="pin">PIN:</label>
				<input type="password" id="pin" name="pin" maxlength="6">
				@error('pin')
				<div class="error">
					<small class="text-danger">{{ $errors->first('pin') }}</small>
				</div>
				@enderror
			</div>	
			<div class="mt-10 float-left">
				<button class="btn btn-primary" type="submit">Checkout</button>		
			</div>




          
        </form>
    </section>



@stop
